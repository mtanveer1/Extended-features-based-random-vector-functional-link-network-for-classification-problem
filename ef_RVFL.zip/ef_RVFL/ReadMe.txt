Some parts of the codes have been taken from the source given in the heading of the code files itself.
A.K. Malik, M. A. Ganaie, M. Tanveer,  and P. N. Suganthan. ``Extended features based random vector functional link network for classification problem"

If you are using the code, please give proper citation

The codes are not optimized for efficiency. The codes have been cleaned for better readability and documented. We have re-run and checked the codes only in few datasets so if you find any bugs/issues, please write to Ashwani Malik (phd1801241003@iiti.ac.in).

