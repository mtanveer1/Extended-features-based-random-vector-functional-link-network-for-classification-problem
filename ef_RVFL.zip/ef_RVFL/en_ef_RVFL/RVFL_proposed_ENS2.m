function [Model,TrainAcc,TestAcc,ProbScores,prelabeltest]  = RVFL_proposed_ENS2(trainX,trainY,testX,testY,option)
% Train RVFL
% U_trainY=unique(trainY);
% nclass=numel(U_trainY);
% trainY_temp=zeros(numel(trainY),nclass);
% % 0-1 coding for the target
% for i=1:nclass
%     idx= trainY==U_trainY(i);
%     trainY_temp(idx,i)=1;
% end
% option.trainY=trainY;
% testY_temp=zeros(numel(testY),nclass);
% for i=1:nclass
%     idx= testY==U_trainY(i);
%     testY_temp(idx,i)=1;
% end
% [RVFLModel,TrainAcc] = RVFL_train(trainX,trainY_temp,option);
% % Using trained model, predict the testing data
% TestAcc = RVFL_predict(testX,testY_temp,RVFLModel);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
s = RandStream('mcg16807','Seed',0);
RandStream.setGlobalStream(s);
%L=50; %% number of ensemble individuals;
L=option.L;
temp=[];
time1=0;
%%
foz = 4; % # of features used for generating new features
order = 2; % order of design matrix used for generating new features
imp_feature_size = 1; % # of generated features equals to imp_feature_size*d(# of original features)
RVFLModel = cell(1,L);
TestAcc= zeros(L,1);
for l=1:L
    %%% obtain the new samples by rotation forest %%%
    K=3;ratio=0.75;
    tic
    % improved space parameters:
    [imp_train_data,imp_test_data] = generate_imp_space(trainX,trainY*[1:size(trainY,2)]',testX,imp_feature_size,foz,order);
    %[RVFLModel{1,l},TrainAcc] = RVFL_train(trainX,trainY,option);
    [RVFLModel{1,l},TrainAcc] = RVFL_train(imp_train_data,trainY,option);
    time1=time1+toc;
    %[~,prelabeltest(:,l)] = RVFL_predict2(testXRFnew,testY_temp,RVFLModel);
    %[prob_scores,prelabeltest(:,l)] = RVFL_predict2(imp_test_data,testY,RVFLModel{1,l},option);%prob_scores is already normalized
    [prob_scores,prelabeltest(:,l)] = RVFL_predict(imp_test_data,testY,RVFLModel{1,l});%prob_scores is already normalized
    ProbScores{l,1} = prob_scores;
	TestAcc(l,1) = ComputeAcc(testY,ProbScores,l);
end
Model.train_time=time1;
Model.RVFLModel=RVFLModel;
%%% voting %%%
% numberindex=[];
% value=[];
% preENCRF=[];
% numbertest=length(testY);
% numberclass=length(U_trainY);
% class=U_trainY;
% for i=1:numbertest
%     prelabelES=[];
%     prelabelES= prelabeltest(i,:);
%     for j=1:numberclass
%         index=[];
%         index=find(prelabelES==class(j));
%         numberindex(i,j)=length(index);
%         
%         
%         
%     end
%     [value(i,1) indexmax(i,1)]=max(numberindex(i,:));
%     preENCRF(i,1)=class(indexmax(i,1));
% end
% %%% compute the accuracy rate of ensemble %%%
% TestAcc=sum(preENCRF==testY)/numbertest;
end
%EOF