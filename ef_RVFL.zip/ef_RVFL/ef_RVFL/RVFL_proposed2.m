function [RVFLModel,TrainAcc,TestAcc,train_time]  = RVFL_proposed2(trainX,trainY,testX,testY,option)

% Train RVFL
% U_trainY=unique(trainY);
% nclass=numel(U_trainY);
% trainY_temp=zeros(numel(trainY),nclass);
% % 0-1 coding for the target
% for i=1:nclass
%     idx= trainY==U_trainY(i);
%     
%     trainY_temp(idx,i)=1;
% end
% option.trainY=trainY;
% improved space parameters:
foz = 4; % # of features used for generating new features
order = 2; % order of design matrix used for generating new features
imp_feature_size = 1; % # of generated features equals to imp_feature_size*d(# of original features)
tic
[imp_train_data,imp_test_data] = generate_imp_space(trainX,trainY*[1:size(trainY,2)]',testX,imp_feature_size,foz,order);
%[RVFLModel,TrainAcc] = RVFL_train(trainX,trainY_temp,option);

[RVFLModel,TrainAcc] = RVFL_train(imp_train_data,trainY,option);
train_time=toc;
% testY_temp=zeros(numel(testY),nclass);
% for i=1:nclass
%     idx= testY==U_trainY(i);
%     
%     testY_temp(idx,i)=1;
% end

% Using trained model, predict the testing data
%TestAcc = RVFL_predict(testX,testY_temp,RVFLModel);
TestAcc = RVFL_predict(imp_test_data,testY,RVFLModel);

end
%EOF